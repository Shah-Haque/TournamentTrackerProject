﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrackerLibrary.Models
{
    public class PersonModel
    {

        /// <summary>
        /// represents the unique ID of the person
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// FirstName of TeamMember
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// LastName of teamMember
        /// </summary>
        public string LastName { get; set; }
        /// <summary>
        /// Emailaddress of team member
        /// </summary>
        public string EmailAddress { get; set; }
        /// <summary>
        /// TelephoneNumber of team member
        /// </summary>
        public string TelephoneNumber { get; set; }
        /// <summary>
        /// shows the fullname of the person
        /// </summary>
        public  string  FullName
        {
            get 
            {
              return $"{FirstName} {LastName}";
            }
        }

    }
} 
