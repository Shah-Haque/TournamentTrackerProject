﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TrackerLibrary;
using TrackerLibrary.Models;

namespace TrackerUI
{
    public partial class TournnamentDashboardForm : Form
    {
        List<TournamentModel> tournaments = GlobalConfig.Connection.GetTournament_All();
        public TournnamentDashboardForm()
        {
            InitializeComponent();

            wireUpLists();
        }

        /// <summary>
        /// This wires up the dropdown list of tournaments
        /// </summary>
        private void wireUpLists()
        {
            LoadExistingTournamentDropdown.DataSource = tournaments;
            LoadExistingTournamentDropdown.DisplayMember = "TournamentName";
        }

        /// <summary>
        /// This Launches a blank CreateTournamentform 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CreateTournamentButton_Click(object sender, EventArgs e)
        {
            CreateTournamentForm frm = new CreateTournamentForm();
            frm.Show();
        }

        /// <summary>
        /// This will load an existing tournament
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoadTournamentButton_Click(object sender, EventArgs e)
        {
            TournamentModel tm = (TournamentModel)LoadExistingTournamentDropdown.SelectedItem;
            TournnamentViewerForm frm = new TournnamentViewerForm(tm);

            frm.Show();
        }
    }
}
