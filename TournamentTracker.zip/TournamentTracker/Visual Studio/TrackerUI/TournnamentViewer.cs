﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Text;
using System.Threading.Tasks;
using TrackerLibrary;
using TrackerLibrary.Models;

namespace TrackerUI
{
    public partial class TournnamentViewerForm : Form
    {
        private TournamentModel tournament;
        BindingList<int> rounds = new BindingList<int>();
        BindingList<MatchupModel> selectedMatchups = new BindingList<MatchupModel>();

        public TournnamentViewerForm(TournamentModel tournamentModel)
        {
            InitializeComponent();

            tournament = tournamentModel;

            tournament.OnTournamentComplete += Tournament_OnTournamentComplete;

            WireupUpLists();

            LoadFormData();

            LoadRounds();

        }

        /// <summary>
        /// This is an event that will be triggered once the tournament is completed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Tournament_OnTournamentComplete(object sender, DateTime e)
        {
            this.Close();
        }

        /// <summary>
        /// This will propulate the form and will display it based from the daat of the other forms 
        /// </summary>
        private void LoadFormData()
        {
            TournamentName.Text = tournament.TournamentName;
        }


        /// <summary>
        /// This Wires up the matchup Lists
        /// </summary>
        private void WireupUpLists()
        {
            RoundDropDown.DataSource = rounds;
            MatchupListBox.DataSource = selectedMatchups;
            MatchupListBox.DisplayMember = "displayName";
        }

        /// <summary>
        /// This will load the rounds
        /// </summary>
        private void LoadRounds()
        {
            rounds.Clear();

            rounds.Add(1);
            int currRound = 1;

            foreach (List<MatchupModel> matchups in tournament.Rounds)
            {
                if (matchups.First().MatchupRound > currRound)
                {
                    currRound = matchups.First().MatchupRound;
                    rounds.Add(currRound);
                }
            }
            LoadMatchups(1);
        }

        /// <summary>
        /// This is the event for the RoundDropdown 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RoundDropDown_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadMatchups((int)RoundDropDown.SelectedItem);
        }

        /// <summary>
        /// This Loads the matchups
        /// </summary>
        private void LoadMatchups(int round)
        {
            foreach (List<MatchupModel> matchups in tournament.Rounds)
            {
                if (matchups.First().MatchupRound == round)
                {
                    selectedMatchups.Clear();

                    foreach (MatchupModel m in matchups)
                    {
                        if (m.Winner == null || !UnplayedOnlyCheckBox.Checked)
                        {
                            selectedMatchups.Add(m);
                        }
                    }
                }
            }
            if (selectedMatchups.Count > 0)
            {
                LoadMatchup(selectedMatchups.First());
            }
            DisplayMatchupInfo();

        }

        /// <summary>
        /// This displays the matchup info
        /// </summary>
        private void DisplayMatchupInfo()
        {
            bool isVisible = (selectedMatchups.Count > 0);

            TeamOneName.Visible = isVisible;
            TeamOneScoreLabel.Visible = isVisible;
            TeamOneScoreValue.Visible = isVisible;
            TeamTwoName.Visible = isVisible;
            TeamTwoScoreLabel.Visible = isVisible;
            TeamTwoScoreValue.Visible = isVisible;
            VersusLabel.Visible = isVisible;
            ScoreButton.Visible = isVisible;
        }

        /// <summary>
        /// This loads up the matchups after the round 
        /// </summary>
        /// <param name = "m" ></ param >
        private void LoadMatchup(MatchupModel m)
        {
            for (int i = 0; i < m.Entries.Count; i++)
            {
                if (i == 0)
                {
                    if (m.Entries[0].TeamCompeting != null)
                    {
                        TeamOneName.Text = m.Entries[0].TeamCompeting.TeamName;
                        TeamOneScoreValue.Text = m.Entries[0].Score.ToString();

                        TeamTwoName.Text = "<bye>";
                        TeamTwoScoreValue.Text = "0";
                    }
                    else
                    {
                        TeamOneName.Text = "Not Yet Set!!!";
                        TeamOneScoreValue.Text = "";
                    }

                }
                if (i == 1)
                {
                    if (m.Entries[1].TeamCompeting != null)
                    {
                        TeamTwoName.Text = m.Entries[1].TeamCompeting.TeamName;
                        TeamTwoScoreValue.Text = m.Entries[1].Score.ToString();
                    }
                    else
                    {
                        TeamTwoName.Text = "Not Yet Set!!!";
                        TeamTwoScoreValue.Text = "";
                    }

                }
            }
        }

        private void MatchupListBox_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            LoadMatchup((MatchupModel)MatchupListBox.SelectedItem);
        }

        private void UnplayedOnlyCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            LoadMatchups((int)RoundDropDown.SelectedItem);
        }

        /// <summary>
        /// This validates the data in the score value for team 1 and team 2
        /// </summary>
        /// <returns></returns>
        private string ValidateData()
        {
            string output = "";

            double teamOneScore = 0;
            double teamTwoScore = 0;

            bool scoreOneValid = double.TryParse(TeamOneScoreValue.Text, out teamOneScore);
            bool scoreTwoValid = double.TryParse(TeamTwoScoreValue.Text, out teamTwoScore);

            if (!scoreOneValid)
            {
                output = "The score one value is not a valid number";
            }
            else if (!scoreTwoValid)
            {
                output = "The score two value is not a valid number";
            }
            else if (teamOneScore == 0 && teamTwoScore == 0)
            {
                output = "You did not enter a score for either team.";
            }
            else if (teamOneScore == teamTwoScore)
            {
                output = "We do not allow ties in this application.";
            }
            return output;
        }

        /// <summary>
        /// This button will have instructions on what to do when the user selects this button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ScoreButton_Click(object sender, EventArgs e)
        {
            // This validates the data entered
            string errorMessage = ValidateData();
            if (errorMessage.Length > 0)
            {
                MessageBox.Show($"Input Error: { errorMessage }");
                return;
            }

            MatchupModel m = (MatchupModel)MatchupListBox.SelectedItem;
            double teamOneScore = 0;
            double teamTwoScore = 0;

            for (int i = 0; i < m.Entries.Count; i++)
            {
                if (i == 0)
                {
                    if (m.Entries[0].TeamCompeting != null)
                    {
                        bool scoreValid = double.TryParse(TeamOneScoreValue.Text, out teamOneScore);

                        if (scoreValid)
                        {
                            m.Entries[0].Score = teamOneScore;
                        }

                        else
                        {
                            MessageBox.Show("Please enter a valid score for team 1.");
                            return;
                        }
                    }
                }
                if (i == 1)
                {
                    bool scoreValid = double.TryParse(TeamTwoScoreValue.Text, out teamTwoScore);

                    if (scoreValid)
                    {
                        m.Entries[1].Score = teamTwoScore;
                    }

                    else
                    {
                        MessageBox.Show("Please enter a valid score for team 2.");
                        return;
                    }
                }
            }
            // This catches any errors and stops the application before it crashes the application
            try
            {
                TournamentLogic.UpdateTournamentResults(tournament);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"The application had the following error: { ex.Message }");
                return;
            }
            LoadMatchups((int)RoundDropDown.SelectedItem);
        }
    }
}