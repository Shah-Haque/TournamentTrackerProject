
-- =============================================
-- Author:		<Author,Shah Haque>
-- =============================================
CREATE PROCEDURE dbo.spPrizes_Insert
	@PlaceNumber int,
	@PlaceName nvarchar(50),
	@PrizeAmount  Money,
	@PrizePercentage float,
	@PrizesID  int= 0 output
AS
BEGIN

	SET NOCOUNT ON;

	insert into dbo.Prizes 
		(PlaceNumber, PlaceName,PrizeAmount,PrizePercentage)
		values(@PlaceNumber,@PlaceName,@PrizeAmount,@PrizePercentage)

		--in the current scope in the prodcure call these 3 procedures in the scope
		select @PrizesID  =  SCOPE_IDENTITY();
	
END
GO
