-- =============================================
-- Author:		<Author,Shah Haque>
-- Create date: <Create Date,26/07/2021,>
-- Description:	<Description,inserts the matchup entries to the matchups list,>
-- =============================================
CREATE PROCEDURE dbo.spMatchUpEntries_insert
@MatchUpID int,
@ParentMatchUpID int,
@TeamCompetingID int,
@MatchUpEntryID int = 0 output
AS
BEGIN

	SET NOCOUNT ON;
	insert into dbo.MatchupEntries(MatchUpID, ParentMatchUpID, TeamCompetingID)
	values(@MatchUpID, @ParentMatchUpID, @TeamCompetingID)

	select @MatchUpEntryID = SCOPE_IDENTITY();
END
GO
