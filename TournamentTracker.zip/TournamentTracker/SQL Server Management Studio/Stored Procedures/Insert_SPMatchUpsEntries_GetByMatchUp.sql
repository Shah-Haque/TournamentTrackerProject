-- =============================================
-- Author:		<Author,Shah Haque>
-- Create date: <Create Date,26/07/2021,>
-- Description:	<Description,Gets all the matchup Entries,>
-- =============================================
CREATE PROCEDURE dbo.spMatchupEntries_getbyMatchup
@MatchUpEntryID int  = 0  output
AS
BEGIN

	SET NOCOUNT ON;
	Select* 
	from dbo.MatchupEntries
END
GO
