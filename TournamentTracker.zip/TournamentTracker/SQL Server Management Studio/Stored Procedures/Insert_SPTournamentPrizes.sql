-- =============================================
-- Author:		<Author,Shah Haque>
-- Create date: <Create Date,16/07/2021,>
-- Description:	<Description,Inserts Tournament Prizes into the Tournament Prize table>
-- =============================================
CREATE PROCEDURE dbo.spTournamentPrizes_Insert
	@TournamentID int,
	@PrizeID int,
	@TournamentPrizeID int = 0 output
AS
BEGIN
	SET NOCOUNT ON;
	
	insert into dbo.TournamentPrizes(TournamentID,PrizeID)
	values(@TournamentID,@PrizeID);

	Select @TournamentPrizeID = SCOPE_IDENTITY();

END
GO
