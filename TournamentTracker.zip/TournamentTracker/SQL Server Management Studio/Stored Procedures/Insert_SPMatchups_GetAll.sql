-- =============================================
-- Author:		<Author,,Shah Haque>
-- Create date: <Create Date,26/07/2021,>
-- Description:	<Description,gets all the matchups,>
-- =============================================
CREATE PROCEDURE SP_Matchups_GetAll

@MatchUpID int = 0 output

AS
BEGIN

Select * 
from Matchup

	SET NOCOUNT ON;

END
GO
