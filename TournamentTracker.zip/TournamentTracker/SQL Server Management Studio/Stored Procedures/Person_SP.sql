
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE dbo.spPerson_GetbyLastName
	@LastName nvarchar(100)
AS
BEGIN
	SET NOCOUNT ON;

	Select *
	from dbo.Person
	where LastName= @LastName;
END
GO
