-- =============================================
-- Author:		<Author,,Shah Haque>
-- Create date: <Create Date,12/07/2021,>
-- Description:	<Description,creates and stores a team member and 
--stores it into the TeamMembers table,>
-- =============================================
CREATE PROCEDURE dbo.spTeamMembers_Insert
	@TeamID int,
	@PersonID int,
	@ID int = 0 output
AS
BEGIN
	SET NOCOUNT ON;
	insert into dbo.TeamMembers(TeamID,PersonID)
		Values(@TeamID,@PersonID)

		Select @ID = SCOPE_IDENTITY();
END
GO
