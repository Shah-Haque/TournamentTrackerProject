-- =============================================
-- Author:		<Author,Shah Haque>
-- Create date: <Create Date,14/09/2021>
-- Description:	<Description,This completes the tournament>
-- =============================================
CREATE PROCEDURE dbo.spTournaments_Complete
	@TournamentID int

AS
BEGIN

	SET NOCOUNT ON;

	update dbo.Tournaments
	set Active = 0
	where TournamentID = @TournamentID;
 
END
GO
