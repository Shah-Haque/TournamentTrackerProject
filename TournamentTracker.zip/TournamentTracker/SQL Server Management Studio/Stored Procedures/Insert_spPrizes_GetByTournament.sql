-- =============================================
-- Author:		<Author,Shah Haque>
-- Create date: <Create Date,23/08/2021>
-- Description:	<Description,This gets the prizes by the Tournament>
-- =============================================
CREATE PROCEDURE dbo.spPrizes_GetByTournament
@TournamentID int

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	select p.*
	from dbo.Prizes p
	inner join dbo.TournamentPrizes t on p.PrizesID = t.PrizeID
	where t.TournamentID = @TournamentID;

END
GO
