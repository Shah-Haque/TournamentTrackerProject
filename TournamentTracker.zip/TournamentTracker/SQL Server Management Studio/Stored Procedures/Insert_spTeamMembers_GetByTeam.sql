-- =============================================
-- Author:		<Author,,Shah Haque>
-- Create date: <Create Date,13/07/2021,>
-- Description:	<Description,gets the teammembers by the team,>
-- =============================================
CREATE PROCEDURE dbo.spTeamMembers_GetByTeam
	@TeamID int
AS
BEGIN

	SET NOCOUNT ON;

	select p.*
	from dbo.TeamMembers m
	inner join dbo.Person p on m.PersonID = p.ID
	where m.TeamID = @TeamID
END
GO
