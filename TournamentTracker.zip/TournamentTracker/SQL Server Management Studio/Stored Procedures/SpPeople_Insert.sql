-- =============================================
-- Author:		<Author,,Shah Haque>
-- Create date: <05/07/2021>
-- Description:	<Stored Procedure for persons>
-- =============================================
CREATE PROCEDURE dbo.SpPeople_Insert
	@FirstName nvarchar(100),
	@LastName nvarchar(100),
	@EmailAddress nvarchar(200),
	@TelephoneNumber varchar(20),
	@ID int = 0 output
AS
BEGIN
	SET NOCOUNT ON;

	insert into dbo.Person
		(FirstName,LastName,EmailAddress,TelephoneNumber)
		Values(@FirstName,@LastName,@EmailAddress,@TelephoneNumber)


Select @ID = SCOPE_IDENTITY();

END
GO
