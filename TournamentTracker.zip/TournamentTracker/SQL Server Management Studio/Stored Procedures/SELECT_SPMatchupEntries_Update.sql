-- Author:		<Author,,Shah Haque>
-- Create date: <Create Date,31/08/2021>
-- Description:	<Description,This updates the matchup entries>
-- =============================================
CREATE PROCEDURE dbo.spMatchupEntries_Update
	@MatchupEntryID int,
	@TeamCompetingID int = null,
	@Score float = null
AS
BEGIN
	SET NOCOUNT ON;
	
	--do not run this command with just update only as the data and rows would be affected
	update dbo.MatchupEntries
	set TeamCompetingID = @TeamCompetingID, Score = @Score
	where MatchupEntryID = @MatchupEntryID
END
GO