-- =============================================
-- Author:		<Author,,Shah Haque>
-- Create date: <Create Date,13/07/2021,>
-- Description:	<Description,gets the current teams for a given tournament,>
-- =============================================
CREATE PROCEDURE dbo.spTeam_GetByTournament
@TournamentID int
	
AS
BEGIN
	SET NOCOUNT ON;

	select t.*
	from dbo.Teams t
	inner join dbo.TournamentEntries e on t.TeamID = e.TeamID
	where e.TournamentID =  @TournamentID;
END
GO
