
-- =============================================
-- Author:		<Author,Shah Haque>
-- Create date: <Create,06/07/2021>
-- Description:	<Stored Procedure to get all people>
-- =============================================
CREATE PROCEDURE dbo.spPeople_GetAll 
	@FirstName nvarchar(100),
	@LastName nvarchar(100),
	@EmailAddress nvarchar(200),
	@TelephoneNumber varchar(20),
	@ID int = 0 output
AS
BEGIN
	SET NOCOUNT ON;

	insert into dbo.Person
		(FirstName,LastName,EmailAddress,TelephoneNumber)
		Values(@FirstName,@LastName,@EmailAddress,@TelephoneNumber)


Select @ID = SCOPE_IDENTITY();
END
GO
