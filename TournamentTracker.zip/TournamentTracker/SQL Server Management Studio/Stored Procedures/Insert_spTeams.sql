-- =============================================
-- Author:		<Author,,Shah Haque>
-- Create date: <Create Date,12/07/2021,>
-- Description:	<Description,stores a Team name in the teams table,>
-- =============================================
CREATE PROCEDURE dbo.spTeams_Insert
	@TeamName nvarchar(100),
	@TeamID int = 0 output
AS
BEGIN

	SET NOCOUNT ON;
	
	insert into dbo.Teams (TeamName)
		values(@TeamName);

	Select @TeamID =  SCOPE_IDENTITY();

END
GO
