
-- =============================================
-- Author:		<Author,,Shah Haque>
-- Create date: <Create Date,13/07/2021,>
-- Description:	<Description,Creates a new tournament,>
-- =============================================
CREATE PROCEDURE dbo.spTeam_GetAll

AS
BEGIN

	SET NOCOUNT ON;
	Select* 
	from dbo.Teams;
END
GO
