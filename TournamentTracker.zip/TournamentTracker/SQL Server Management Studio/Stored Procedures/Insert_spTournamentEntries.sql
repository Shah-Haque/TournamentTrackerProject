-- =============================================
-- Author:		<Author, Shah Haque>
-- Create date: <Create Date,16/07/2021>
-- Description:	<Description,Creates a Tournament Entry in the Tournament Entires table>
-- =============================================
CREATE PROCEDURE dbo.spTournamentEntries_Insert
	@TournamentID int,
	@TeamID int,
	@TournamentEntriesID int = 0 output
AS
BEGIN
	SET NOCOUNT ON;

	insert into dbo.TournamentEntries (TournamentID,TeamID)
	values(@TournamentID, @TeamID)

	select TournamentEntriesID = SCOPE_IDENTITY();

END
GO
