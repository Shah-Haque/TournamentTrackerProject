-- =============================================
-- Author:		<Author,,shah Haque>
-- Create date: <Create Date, 26/07/2021,>
-- Description:	<Description,This inserts all the matchups in the tournment file,>
-- =============================================
CREATE PROCEDURE dbo.SPMatchups_Insert
	@TournamentID int,
	@WinnerID int,
	@MatchUpRound int,
	@MatchUpID int = 0 output
AS
BEGIN

	SET NOCOUNT ON;

	Insert into dbo.Matchup (TournamentID, MatchUpRound)
	values(@TournamentID, @MatchUpRound)

	select @MatchUpID = SCOPE_IDENTITY();
END
GO
