-- Author:		<Author,,Shah Haque>
-- Create date: <Create Date,16/07/2021,>
-- Description:	<Description,creates and stores a tournament in the Tournament table,>
-- =============================================
CREATE PROCEDURE dbo.spTournaments_insert
	@TournamentName nvarchar(200),
	@EntryFee money,
	@TournamentID int = 0 output
AS
BEGIN

	SET NOCOUNT ON;

	insert into dbo.Tournaments (TournamentName, EntryFee, Active)
	values(@TournamentName, @EntryFee, 1);
END
GO
