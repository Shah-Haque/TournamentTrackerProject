-- Author:		<Author,,Shah Haque>
-- Create date: <Create Date,31/08/2021>
-- Description:	<Description,Updates the existing matchups>
-- =============================================
CREATE PROCEDURE dbo.spMatchups_Update
	@MatchupID int,
	@WinnerID int
AS
BEGIN
	
	SET NOCOUNT ON;

	--don't hit or highlight update code only as it will alter all records
	update dbo.Matchups
	set WinnerId = @WinnerID
	where MatchupID = @MatchupID
   
END
GO